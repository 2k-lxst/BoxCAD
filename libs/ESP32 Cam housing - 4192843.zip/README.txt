ESP32 Cam housing by laisch on Thingiverse: https://www.thingiverse.com/thing:4192843

Summary:
Housing for ESP32 Cam modul (Tinker board)